import os
import shutil

current_dir = os.path.dirname(os.path.realpath(__file__))
class edit_svg_files:
	def edit(self):
	 	for filename in os.listdir(current_dir):
	 		if filename.endswith((".svg")):
	 			open_file = open(filename,'r')
	 			text_file = str(open_file.readlines(1))
	 			text_file = text_file.replace('stroke="red"', 'stroke="gray"')
	 			text_file = text_file.replace('[\'','')
	 			text_file = text_file.replace('\']','')
	 			open_file = open(filename,'w')
	 			open_file.write(text_file)
	 			open_file.close()
	 			print(filename+" Done")

start = edit_svg_files()
start.edit()
